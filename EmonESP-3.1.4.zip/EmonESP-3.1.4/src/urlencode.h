#ifndef urlencode_h
#define urlencode_h

#include <Arduino.h>

String urldecode(String str);
String urlencode(String str);

#endif // urlencode_h