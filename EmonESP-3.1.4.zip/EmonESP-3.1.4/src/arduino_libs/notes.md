These libraries are for adding to your ArduinoIDE libraries directiory, if required.
